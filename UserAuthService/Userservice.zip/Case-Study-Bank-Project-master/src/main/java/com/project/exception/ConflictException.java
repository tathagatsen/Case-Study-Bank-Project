package com.project.exception;

public class ConflictException extends RuntimeException {
public ConflictException(String msg) { super(msg); }
}